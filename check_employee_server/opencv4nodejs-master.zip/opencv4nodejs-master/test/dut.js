/* eslint-disable */

// manipulate binary path for testing
//process.env.path = process.env.path.replace(process.env.OPENCV_BIN_DIR, process.env.OPENCV30_BIN_DIR);

module.exports = () => require(process.env.DUT_INSTALLED ? 'opencv4nodejs' : '../');
