#include "NativeNodeUtils.h"
#include "macros.h"
#include "opencv2/face.hpp"

#ifndef __FF_FACE_H__
#define __FF_FACE_H__

class Face {
public:
  static NAN_MODULE_INIT(Init);
};

#endif