#include "macros.h"

#ifndef __FF_XFEATURES2D_H__
#define __FF_XFEATURES2D_H__

class XFeatures2d {
public:
	static NAN_MODULE_INIT(Init);
};

#endif