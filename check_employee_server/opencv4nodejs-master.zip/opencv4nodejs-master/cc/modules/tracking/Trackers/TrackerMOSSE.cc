#ifdef HAVE_TRACKING

#include "TrackerMOSSE.h"

#if CV_MINOR_VERSION > 3

Nan::Persistent<v8::FunctionTemplate> TrackerMOSSE::constructor;

NAN_MODULE_INIT(TrackerMOSSE::Init) {
	v8::Local<v8::FunctionTemplate> ctor = Nan::New<v8::FunctionTemplate>(TrackerMOSSE::New);
	v8::Local<v8::ObjectTemplate> instanceTemplate = ctor->InstanceTemplate();

	Tracker::Init(ctor);

	constructor.Reset(ctor);
	ctor->SetClassName(FF::newString("TrackerMOSSE"));
	instanceTemplate->SetInternalFieldCount(1);

	Nan::Set(target,FF::newString("TrackerMOSSE"), FF::getFunction(ctor));
};


NAN_METHOD(TrackerMOSSE::New) {
	FF_ASSERT_CONSTRUCT_CALL(TrackerMOSSE);
	FF_METHOD_CONTEXT("TrackerMOSSE::New");

	TrackerMOSSE* self = new TrackerMOSSE();
	self->tracker = cv::TrackerMOSSE::create();
	self->Wrap(info.Holder());
	info.GetReturnValue().Set(info.Holder());
};

#endif

#endif
