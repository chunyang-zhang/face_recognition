# opencv4nodejs TypeScript examples

### Install
``` bash
npm install
```

### Run
``` bash
npm run ts-node <example>.ts
```