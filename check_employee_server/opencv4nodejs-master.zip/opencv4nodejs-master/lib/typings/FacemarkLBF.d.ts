import { Facemark } from "./Facemark";

export class FacemarkLBF extends Facemark {}
