import { FaceRecognizer } from './FaceRecognizer';

export class EigenFaceRecognizer extends FaceRecognizer {
  constructor(num_components?: number, threshold?: number);
}
