import { Facemark } from "./Facemark";

export class FacemarkAAM extends Facemark {}
